<?php 

  phpinfo();
  
?>
