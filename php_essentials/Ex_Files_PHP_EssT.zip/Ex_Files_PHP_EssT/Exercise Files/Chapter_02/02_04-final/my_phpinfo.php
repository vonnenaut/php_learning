<?php 

  phpinfo();
  
?>

